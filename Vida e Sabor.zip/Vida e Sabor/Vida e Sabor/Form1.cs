﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vida_e_Sabor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            float valor = float.Parse(txtPrecoVenda.Text);
            float imposto = float.Parse(txtAliquota.Text);
            float valimposto = 0;

            valimposto = valor * imposto;

            MessageBox.Show("Cadastro Realizado com sucesso! O imposto a pagar é de " + valimposto);

        }
    }
}
